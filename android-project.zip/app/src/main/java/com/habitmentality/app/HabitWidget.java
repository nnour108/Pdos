package com.habitmentality.app;
import android.app.PendingIntent;import android.appwidget.*;import android.content.*;import android.widget.RemoteViews;import org.json.JSONObject;
public class HabitWidget extends AppWidgetProvider{
 public void onUpdate(Context c,AppWidgetManager m,int[] ids){for(int i:ids)m.updateAppWidget(i,build(c));}
 static RemoteViews build(Context c){RemoteViews r=new RemoteViews(c.getPackageName(),R.layout.widget);
  try{JSONObject o=new JSONObject(c.getSharedPreferences("w",0).getString("j","{}"));int p=o.optInt("p",0);
   r.setTextViewText(R.id.pct,p+"%");r.setTextViewText(R.id.sub,o.optInt("d",0)+" / "+o.optInt("n",0)+" عادة اليوم");r.setProgressBar(R.id.bar,100,p,false);
   r.setTextViewText(R.id.st,o.optString("s",""));r.setTextViewText(R.id.list,o.optString("t","افتح التطبيق لتحديث البيانات"));}catch(Exception e){}
  r.setOnClickPendingIntent(R.id.root,PendingIntent.getActivity(c,0,new Intent(c,MainActivity.class),PendingIntent.FLAG_IMMUTABLE|PendingIntent.FLAG_UPDATE_CURRENT));return r;}
 static void refresh(Context c){AppWidgetManager m=AppWidgetManager.getInstance(c);for(int i:m.getAppWidgetIds(new ComponentName(c,HabitWidget.class)))m.updateAppWidget(i,build(c));}
}

package com.habitmentality.app;
import android.Manifest;import android.app.*;import android.content.ContentValues;import android.content.Intent;import android.net.Uri;import android.os.Build;import android.os.Bundle;import android.os.CancellationSignal;import android.os.Environment;import android.provider.MediaStore;import android.webkit.*;import android.widget.Toast;
import androidx.core.content.ContextCompat;
import androidx.credentials.Credential;import androidx.credentials.CredentialManager;import androidx.credentials.CredentialManagerCallback;import androidx.credentials.CustomCredential;import androidx.credentials.GetCredentialRequest;import androidx.credentials.GetCredentialResponse;import androidx.credentials.exceptions.GetCredentialException;
import com.google.android.libraries.identity.googleid.GetGoogleIdOption;import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential;
import org.json.JSONObject;import java.io.File;import java.io.FileOutputStream;import java.io.OutputStream;
public class MainActivity extends Activity{
 static final String URL="https://nnour108.github.io/Pdos/";WebView w;ValueCallback<Uri[]> fcb;
 static final String POLY="(function(){if(window.__hm)return;window.__hm=1;function N(t,o){try{AndroidBridge.notify(String(t),String((o&&o.body)||''))}catch(e){}}N.permission='granted';N.requestPermission=function(c){try{AndroidBridge.requestNotif()}catch(e){}if(c)c('granted');return Promise.resolve('granted')};window.Notification=N;if(navigator.serviceWorker){navigator.serviceWorker.getRegistration=function(){return Promise.resolve(null)}}"
  +"document.addEventListener('click',function(e){var a=e.target&&e.target.closest?e.target.closest('a[download]'):null;if(!a||!a.href||a.href.indexOf('blob:')!==0)return;e.preventDefault();var n=a.download||'file';fetch(a.href).then(function(r){return r.blob()}).then(function(b){var f=new FileReader();f.onload=function(){try{AndroidBridge.saveFile(n,b.type||'application/octet-stream',String(f.result).split(',')[1])}catch(x){}};f.readAsDataURL(b)})},true)})();";
 protected void onCreate(Bundle b){super.onCreate(b);w=new WebView(this);setContentView(w);
  WebSettings s=w.getSettings();s.setJavaScriptEnabled(true);s.setDomStorageEnabled(true);s.setDatabaseEnabled(true);s.setMediaPlaybackRequiresUserGesture(false);
  w.setLongClickable(false);w.setOnLongClickListener(v->true);w.setHapticFeedbackEnabled(false);
  w.addJavascriptInterface(new Br(),"AndroidBridge");
  w.setWebChromeClient(new WebChromeClient(){
   public boolean onShowFileChooser(WebView v,ValueCallback<Uri[]> cb,FileChooserParams p){if(fcb!=null)fcb.onReceiveValue(null);fcb=cb;try{startActivityForResult(p.createIntent(),77)}catch(Exception e){fcb=null;return false}return true;}});
  w.setWebViewClient(new WebViewClient(){
   public boolean shouldOverrideUrlLoading(WebView v,WebResourceRequest r){Uri u=r.getUrl();if("nnour108.github.io".equals(u.getHost()))return false;try{startActivity(new Intent(Intent.ACTION_VIEW,u));}catch(Exception e){}return true;}
   public void onPageFinished(WebView v,String u){v.evaluateJavascript(POLY,null);}});
  w.loadUrl(URL);}
 protected void onActivityResult(int rq,int rs,Intent d){if(rq==77&&fcb!=null){fcb.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(rs,d));fcb=null}else super.onActivityResult(rq,rs,d);}
 public void onBackPressed(){if(w.canGoBack())w.goBack();else super.onBackPressed();}
 protected void onPause(){super.onPause();CookieManager.getInstance().flush();}
 void js(final String code){runOnUiThread(()->w.evaluateJavascript(code,null));}
 void toast(final String m){runOnUiThread(()->Toast.makeText(MainActivity.this,m,Toast.LENGTH_LONG).show());}
 class Br{
  @JavascriptInterface public void requestNotif(){if(Build.VERSION.SDK_INT>=33)runOnUiThread(()->requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},1));}
  @JavascriptInterface public void notify(String t,String m){NotificationManager nm=(NotificationManager)getSystemService(NOTIFICATION_SERVICE);
   if(Build.VERSION.SDK_INT>=26)nm.createNotificationChannel(new NotificationChannel("hm","HABIT MENTALITY",NotificationManager.IMPORTANCE_DEFAULT));
   PendingIntent pi=PendingIntent.getActivity(MainActivity.this,0,new Intent(MainActivity.this,MainActivity.class),PendingIntent.FLAG_IMMUTABLE);
   Notification.Builder nb=Build.VERSION.SDK_INT>=26?new Notification.Builder(MainActivity.this,"hm"):new Notification.Builder(MainActivity.this);
   nm.notify((int)System.currentTimeMillis(),nb.setSmallIcon(android.R.drawable.ic_dialog_info).setContentTitle(t).setContentText(m).setContentIntent(pi).setAutoCancel(true).build());}
  @JavascriptInterface public void widget(String j){getSharedPreferences("w",0).edit().putString("j",j).apply();HabitWidget.refresh(MainActivity.this);}
  @JavascriptInterface public void saveFile(String name,String mime,String b64){try{byte[] d=android.util.Base64.decode(b64,0);
   if(Build.VERSION.SDK_INT>=29){ContentValues v=new ContentValues();v.put(MediaStore.Downloads.DISPLAY_NAME,name);v.put(MediaStore.Downloads.MIME_TYPE,mime);v.put(MediaStore.Downloads.RELATIVE_PATH,Environment.DIRECTORY_DOWNLOADS);Uri u=getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI,v);OutputStream o=getContentResolver().openOutputStream(u);o.write(d);o.close();}
   else{File f=new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS),name);FileOutputStream o=new FileOutputStream(f);o.write(d);o.close();}
   toast("تم الحفظ في التنزيلات: "+name);}catch(Exception e){toast("تعذر حفظ الملف");}}
  @JavascriptInterface public void googleSignIn(final String webClientId){runOnUiThread(()->{try{
   GetGoogleIdOption opt=new GetGoogleIdOption.Builder().setFilterByAuthorizedAccounts(false).setServerClientId(webClientId).setAutoSelectEnabled(false).build();
   GetCredentialRequest req=new GetCredentialRequest.Builder().addCredentialOption(opt).build();
   CredentialManager cm=CredentialManager.create(MainActivity.this);
   cm.getCredentialAsync(MainActivity.this,req,new CancellationSignal(),ContextCompat.getMainExecutor(MainActivity.this),new CredentialManagerCallback<GetCredentialResponse,GetCredentialException>(){
    public void onResult(GetCredentialResponse r){try{Credential c=r.getCredential();
     if(c instanceof CustomCredential&&GoogleIdTokenCredential.TYPE_GOOGLE_ID_TOKEN_CREDENTIAL.equals(c.getType())){GoogleIdTokenCredential g=GoogleIdTokenCredential.createFrom(((CustomCredential)c).getData());
      JSONObject o=new JSONObject();o.put("n",g.getDisplayName()==null?g.getId():g.getDisplayName());o.put("e",g.getId());o.put("p",g.getProfilePictureUri()==null?"":g.getProfilePictureUri().toString());o.put("id",g.getId());
      js("window.hmNativeGoogle("+o.toString()+")");}
     else js("window.hmNativeErr("+JSONObject.quote("نوع الحساب غير مدعوم")+")");}catch(Exception e){js("window.hmNativeErr("+JSONObject.quote("تعذر قراءة الحساب")+")");}}
    public void onError(GetCredentialException e){String m=e.getMessage()==null?"تم الإلغاء":e.getMessage();js("window.hmNativeErr("+JSONObject.quote(e.getClass().getSimpleName()+": "+m)+")");}});
  }catch(Exception e){js("window.hmNativeErr("+JSONObject.quote(String.valueOf(e.getMessage()))+")");}});}
 }
}

package com.habitmentality.app;
import android.Manifest;import android.app.*;import android.content.Intent;import android.net.Uri;import android.os.Build;import android.os.Bundle;import android.webkit.*;
public class MainActivity extends Activity{
 static final String URL="https://nnour108.github.io/Pdos/";WebView w;
 static final String POLY="(function(){if(window.__hm)return;window.__hm=1;function N(t,o){try{AndroidBridge.notify(String(t),String((o&&o.body)||''))}catch(e){}}N.permission='granted';N.requestPermission=function(c){try{AndroidBridge.requestNotif()}catch(e){}if(c)c('granted');return Promise.resolve('granted')};window.Notification=N;if(navigator.serviceWorker){navigator.serviceWorker.getRegistration=function(){return Promise.resolve(null)}}})();";
 protected void onCreate(Bundle b){super.onCreate(b);w=new WebView(this);setContentView(w);
  WebSettings s=w.getSettings();s.setJavaScriptEnabled(true);s.setDomStorageEnabled(true);s.setDatabaseEnabled(true);s.setMediaPlaybackRequiresUserGesture(false);
  w.setLongClickable(false);w.setOnLongClickListener(v->true);w.setHapticFeedbackEnabled(false);
  w.addJavascriptInterface(new Br(),"AndroidBridge");
  w.setWebViewClient(new WebViewClient(){
   public boolean shouldOverrideUrlLoading(WebView v,WebResourceRequest r){Uri u=r.getUrl();if("nnour108.github.io".equals(u.getHost()))return false;try{startActivity(new Intent(Intent.ACTION_VIEW,u));}catch(Exception e){}return true;}
   public void onPageFinished(WebView v,String u){v.evaluateJavascript(POLY,null);}});
  w.loadUrl(URL);}
 public void onBackPressed(){if(w.canGoBack())w.goBack();else super.onBackPressed();}
 protected void onPause(){super.onPause();CookieManager.getInstance().flush();}
 class Br{
  @JavascriptInterface public void requestNotif(){if(Build.VERSION.SDK_INT>=33)runOnUiThread(()->requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},1));}
  @JavascriptInterface public void notify(String t,String m){NotificationManager nm=(NotificationManager)getSystemService(NOTIFICATION_SERVICE);
   if(Build.VERSION.SDK_INT>=26)nm.createNotificationChannel(new NotificationChannel("hm","HABIT MENTALITY",NotificationManager.IMPORTANCE_DEFAULT));
   PendingIntent pi=PendingIntent.getActivity(MainActivity.this,0,new Intent(MainActivity.this,MainActivity.class),PendingIntent.FLAG_IMMUTABLE);
   Notification.Builder nb=Build.VERSION.SDK_INT>=26?new Notification.Builder(MainActivity.this,"hm"):new Notification.Builder(MainActivity.this);
   nm.notify((int)System.currentTimeMillis(),nb.setSmallIcon(android.R.drawable.ic_dialog_info).setContentTitle(t).setContentText(m).setContentIntent(pi).setAutoCancel(true).build());}
  @JavascriptInterface public void widget(String j){getSharedPreferences("w",0).edit().putString("j",j).apply();HabitWidget.refresh(MainActivity.this);}
 }
}
